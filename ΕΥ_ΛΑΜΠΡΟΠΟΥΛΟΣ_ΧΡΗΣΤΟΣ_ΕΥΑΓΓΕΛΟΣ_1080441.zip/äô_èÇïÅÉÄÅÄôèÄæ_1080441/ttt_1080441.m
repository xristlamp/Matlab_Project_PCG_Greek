function C = ttt_1080441(A, B, mode)
    if nargin < 3
        % Outer product of tensors
        C = outerProduct(A, B);
    elseif strcmp(mode, 'all')
        % Inner product of tensors
        if ~isequal(size(A), size(B))
            error('The dimensions of tensors A and B must be the same for the inner product.');
        end
        C = sum(A(:) .* B(:));
    else
        error('The third parameter must be ''all'' or omitted.');
    end
end

function C = outerProduct(A, B)
    % Computes the outer product of two tensors A and B
    aSize = size(A);
    bSize = size(B);
    C = zeros([aSize, bSize]);
    for i = 1:numel(A)
        C(i) = A(i) .* B;
    end
    C = reshape(C, [aSize, bSize]);
end
