function Y = ttv_1080441(X, V, N)
    % Check if dimensions match
    if size(X, N) ~= length(V)
        error('The dimension N of the tensor X does not match the length of the vector V.');
    end
    
    % Check if V is a vector
    if ~isvector(V)
        error('The input V must be a vector.');
    end
    
    % Reshape V into a column vector if it is not already
    V = V(:);
    
    % Initialize the result tensor Y to X
    dimensions = size(X);
    dimensions(N) = []; % Remove the N-th dimension
    Y = zeros(dimensions);
    
    % Multiply the tensor by the vector along the N-th dimension
    for i = 1:length(V)
        indices = repmat({':'}, 1, ndims(X));
        indices{N} = i;
        Y(indices{:}) = bsxfun(@times, X(indices{:}), V(i));
    end
end
