% Define a symmetric positive definite matrix A
n = 10; % Size of the matrix
A = gallery('lehmer',n); % Generates a symmetric positive definite matrix

% Define a vector b
b = rand(n,1); % A random vector

% Set the tolerance and maximum number of iterations for the PCG algorithm
tol = 1e-10;
maxit = n;

% No preconditioner in this simple example
M1 = []; % You can replace [] with a preconditioner matrix if you have one

% Measure computation time
tic;

% Solve the system using the PCG method
[x,flag,relres,iter,resvec] = pcg(A,b,tol,maxit,M1);

% Measure computation time end
toc;

% Display the results
disp(['The solution vector x is: ']);
disp(x);
disp(['The PCG method converged with flag: ' num2str(flag)]);
disp(['The relative residual is: ' num2str(relres)]);
disp(['The number of iterations was: ' num2str(iter)]);
disp(['The residual at each iteration was: ']);
disp(resvec);

% Verify the solution by calculating the error
error = norm(A*x - b) / norm(b);
disp(['The relative error of the solution is: ' num2str(error)]);

% Optional: Plot the convergence
figure;
semilogy(resvec/norm(b),'-o');
xlabel('Iteration number');
ylabel('Relative residual');
title('Convergence of PCG method');
