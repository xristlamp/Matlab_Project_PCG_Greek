     % Range of n values for n x n matrices
n_values = 100:100:2000;
execution_times = zeros(length(n_values), 1);

% Collect execution times
for i = 1:length(n_values)
    n = n_values(i);
    A = rand(n, n);
    A = A' * A; % Ensures matrix is symmetric positive definite
    f = @() chol(A);
    execution_times(i) = timeit(f);
end

% Handling outliers if necessary
% outliers = isoutlier(execution_times);
% execution_times(outliers) = median(execution_times);

% Perform polynomial fitting
% Here 'mu' is used for normalization
[p, ~, mu] = polyfit(n_values, execution_times, 3);

% Display coefficients
disp('Normalized cubic polynomial coefficients (a3, a2, a1, a0):');
disp(p);

% Visualization
figure;
scatter(n_values, execution_times, 'filled');
hold on;
fitted_times = polyval(p, n_values, [], mu);
plot(n_values, fitted_times, 'r', 'LineWidth', 2);
xlabel('Matrix size (n)');
ylabel('Execution time (seconds)');
legend('Measured times', 'Cubic fit');
title('Execution Time of chol(A) vs Matrix Size');
hold off;
