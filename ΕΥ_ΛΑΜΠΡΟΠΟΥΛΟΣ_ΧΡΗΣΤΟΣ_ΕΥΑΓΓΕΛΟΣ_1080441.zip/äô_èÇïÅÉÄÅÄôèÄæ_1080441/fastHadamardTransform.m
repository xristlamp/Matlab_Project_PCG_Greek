function H = fastHadamardTransform(n)
    % Check if n is a power of 2
    if mod(n, 2) ~= 0
        error('n must be a power of 2');
    end
    
    % Initialize Hadamard matrix
    H = 1;
    
    % Construct the Hadamard matrix using Sylvester's construction
    for i = 1:log2(n)
        H = kron(H, [1, 1; 1, -1]);
    end
    
    % Normalize
    H = H / sqrt(n);
end
