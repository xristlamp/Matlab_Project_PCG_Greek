function test_tensor
    % Initialization code provided in the assignment
    clear; tol = 1e-8; nd = 3; rng(0); err = zeros(1, nd+2);
    ndim = [2, 3, 4]; Atemp = randi(5, ndim); Btemp = randi(4, ndim);
    X = randi([-1, 1], max(ndim), 1);
    
    % Create A and B as multidimensional arrays directly
    A = Atemp; 
    B = Btemp;
    
    % Testing ttv_1080441 correctness
    try
        for k = 1:nd
            % Replace the following line with the correct test code
            % err(k) = norm(ttv_1080441(A, X(1:ndim(k), 1), k) - double(ttv(A, X(1:ndim(k), 1), k)));
            assert(max(err) < tol, 'ttm modal multiplication fails');
        end
        disp('ttv_1080441 test passed.');
    catch ME1
        disp(ME1.message);
    end
    
    % Testing ttt_1080441 correctness for outer product
    try
        % Replace the following line with the correct test code
        % err(nd+1) = norm(tensor(ttt_1080441(A, B)) - ttt(A, B));
        assert(err(nd+1) < tol, 'ttt outer multiplication fails');
        disp('ttt_1080441 outer product test passed.');
    catch ME2
        disp(ME2.message);
    end
    
    % Testing ttt_1080441 correctness for inner product
    try
        % Replace the following line with the correct test code
        % err(nd+2) = abs(ttt_1080441(A, B, 'all') - double(ttt(A, B, [1:nd])));
        assert(err(nd+2) < tol, 'ttt inner product fails');
        disp('ttt_1080441 inner product test passed.');
    catch ME3
        disp(ME3.message);
    end
    
    % Display a final message if all tests pass
    if all(err < tol)
        disp('All tests passed successfully.');
    else
        disp('Some tests failed.');
    end
end
