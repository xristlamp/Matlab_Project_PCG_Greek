function [A, B_shifted] = createTridiagonal(n)
    % createTridiagonal creates a tridiagonal matrix A of size n and a shifted vector B
    % Input: n - size of the matrix A
    % Output: A - tridiagonal matrix, B_shifted - shifted vector B

    % Define the diagonals
    main_diag = 4 * ones(n, 1); % Main diagonal of A
    sub_diag = -1 * ones(n-1, 1); % Sub-diagonal of A
    sup_diag = -1 * ones(n-1, 1); % Super-diagonal of A

    % Create the tridiagonal matrix A
    A = diag(sub_diag, -1) + diag(main_diag) + diag(sup_diag, 1);

    % Create and shift array B
    B = ones(n, 1); % Replace with actual values for B if necessary
    B_shifted = [0; B(1:end-1)]; % Shift B one place to the right
end

%ΑΥΤΟ ΕΙΝΑΙ ΤΟ ΕΡΩΤΗΜΑ 2.1
