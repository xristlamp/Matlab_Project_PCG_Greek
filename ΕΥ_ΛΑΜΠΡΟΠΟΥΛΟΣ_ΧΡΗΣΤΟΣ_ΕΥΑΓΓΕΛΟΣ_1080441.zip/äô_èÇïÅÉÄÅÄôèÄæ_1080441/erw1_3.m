
% Full range of n values
n_full = 100:100:2000;
% Calculate polynomial values for full range
poly_values_full = polyval(coefficients_n, n_full);

% Plot the actual execution times with 'o' markers
figure;
plot(n_values, execution_times_n, 'o', 'MarkerSize', 4, 'MarkerFaceColor', 'b');
hold on; % Keep the plot active to overlay the polynomial fit

% Plot the polynomial fit with a continuous line
plot(n_full, poly_values_full, 'r-', 'LineWidth', 2);

% Enhance the plot
title('Execution Time and Polynomial Fit for Full Range of Matrix Sizes');
xlabel('Matrix size (n)');
ylabel('Execution time (seconds)');
legend('Actual execution times', 'Polynomial fit');
grid on;
hold off; % Release the plot
