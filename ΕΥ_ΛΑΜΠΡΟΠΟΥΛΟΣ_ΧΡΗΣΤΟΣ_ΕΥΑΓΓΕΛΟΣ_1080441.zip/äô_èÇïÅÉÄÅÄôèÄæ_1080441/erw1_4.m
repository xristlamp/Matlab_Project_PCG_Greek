
% Fit a second-degree polynomial
coeffs_quad = polyfit(n_values, execution_times_n, 2);

% Fit a fourth-degree polynomial
coeffs_quartic = polyfit(n_values, execution_times_n, 4);

% Calculate values from the fitted polynomials
quad_values = polyval(coeffs_quad, n_values);
quartic_values = polyval(coeffs_quartic, n_values);

% Compare the fits visually
figure;
hold on;
scatter(n_values, execution_times_n, 'o'); % Actual execution times
plot(n_values, polyval(coefficients_n, n_values), 'r-', 'LineWidth', 2); % Cubic fit
plot(n_values, quad_values, 'g-', 'LineWidth', 2); % Quadratic fit
plot(n_values, quartic_values, 'b-', 'LineWidth', 2); % Quartic fit
title('Comparison of Polynomial Fits');
xlabel('Matrix size (n)');
ylabel('Execution time (seconds)');
legend('Measured times', 'Cubic fit', 'Quadratic fit', 'Quartic fit');
hold off;
