% Range of n values for n x n matrices
n_values = 100:100:2000; % For the full range
m_values = 150:100:1550; % For the reduced range

% Initialize matrices to store execution times
execution_times_n = zeros(length(n_values), 1);
execution_times_m = zeros(length(m_values), 1);

% Measure execution time for each n
for i = 1:length(n_values)
    n = n_values(i);
    A = rand(n, n);
    A = A' * A; % Make A symmetric positive definite

    % Time the chol function
    f = @() chol(A);
    execution_times_n(i) = timeit(f);
end

% Repeat measurement for the reduced range m
for j = 1:length(m_values)
    m = m_values(j);
    B = rand(m, m);
    B = B' * B; % Make B symmetric positive definite

    % Time the chol function
    g = @() chol(B);
    execution_times_m(j) = timeit(g);
end

% Manually compute the coefficients for the cubic polynomial fit
% Define the Vandermonde matrix for n
V_n = [n_values.^3; n_values.^2; n_values; ones(size(n_values))].';
% Solve for coefficients for n
coefficients_n = V_n \ execution_times_n;

% Define the Vandermonde matrix for m
V_m = [m_values.^3; m_values.^2; m_values; ones(size(m_values))].';
% Solve for coefficients for m
coefficients_m = V_m \ execution_times_m;

% Display the coefficients
fprintf('Cubic polynomial coefficients for n range (a3, a2, a1, a0):\n');
disp(coefficients_n);
fprintf('Cubic polynomial coefficients for m range (a3, a2, a1, a0):\n');
disp(coefficients_m);
