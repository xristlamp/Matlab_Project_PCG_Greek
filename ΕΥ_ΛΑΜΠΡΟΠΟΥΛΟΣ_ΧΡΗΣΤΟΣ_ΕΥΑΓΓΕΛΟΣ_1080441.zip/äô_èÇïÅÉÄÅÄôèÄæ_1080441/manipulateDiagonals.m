function [mainDiagNorm, secDiagNorm] = manipulateDiagonals(A)
    % A is the input matrix
    
    % Get the main diagonal of A
    mainDiag = diag(A);
    mainDiagNorm = norm(mainDiag); % Calculate the norm of the main diagonal
    
    % Get the secondary diagonal of A
    secDiag = diag(flipud(A));
    secDiagNorm = norm(secDiag); % Calculate the norm of the secondary diagonal
    
    % Example operation: swap the main diagonal and secondary diagonal
    A = A - diag(mainDiag) + diag(secDiag); % Remove the main diagonal
    A = flipud(A); % Flip the A matrix upside down
    A = A - diag(diag(A)) + diag(mainDiag); % Remove the secondary diagonal and add the main
    A = flipud(A); % Re-flip the A matrix to the original orientation
    
    % Display the norms
    fprintf('Norm of the main diagonal: %f\n', mainDiagNorm);
    fprintf('Norm of the secondary diagonal: %f\n', secDiagNorm);
end

%ΓΙΑ ΝΑ ΤΡΕΞΕΤΕ ΤΟΝ ΚΩΔΙΚΑ
% Δημιουργία ενός πίνακα με διαφορετικές τιμές στην κύρια και δευτερεύουσα διαγώνιο
%A = [1, 2, 3; 4, 5, 6; 7, 8, 9];

% Κλήση της συνάρτησης για τον νέο πίνακα
%[mainDiagNorm, secDiagNorm] = manipulateDiagonals(A);

% Εμφάνιση των νορμών
%fprintf('Norm of the main diagonal: %f\n', mainDiagNorm);
%fprintf('Norm of the secondary diagonal: %f\n', secDiagNorm);
